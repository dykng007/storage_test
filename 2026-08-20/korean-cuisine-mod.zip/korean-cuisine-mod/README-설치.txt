=== Korean Cuisine Mod 설치 방법 ===

【준비물】
1. Minecraft 1.21.1 자바 에디션
2. Forge 1.21.1 (버전 52.0.9 이상)

【설치 순서】

■ 1단계: Forge 설치
  - https://files.minecraftforge.net/ 접속
  - Minecraft 1.21.1용 Forge 다운로드
  - 다운받은 설치 파일 실행 → "Install client" 선택 → 설치

■ 2단계: 모드 빌드 (개발자용)
  이 소스 코드를 받으셨다면:
  
  Windows:
    gradlew.bat build
  
  Mac/Linux:
    ./gradlew build
  
  → build/libs/ 폴더에 .jar 파일 생성됨

■ 3단계: 모드 파일 배치
  - Minecraft 런처 실행
  - "설치 설정" → Forge 프로필 선택 → 폴더 아이콘(게임 디렉토리 열기) 클릭
  - mods 폴더 열기 (없으면 생성)
  - korean-cuisine-mod-1.0.0.jar 파일을 mods 폴더에 복사

■ 4단계: 게임 실행
  - Minecraft 런처에서 Forge 프로필 선택
  - 게임 시작
  - 메인 메뉴에서 "Mods" 버튼 클릭 → 목록에 "Korean Cuisine Mod" 확인

【게임 내 사용법】

▣ 작물 재배
  1. 크리에이티브 모드 또는 /give 명령어로 씨앗 획득:
     /give @p koreancuisine:cabbage_seeds
     /give @p koreancuisine:radish_seeds
     /give @p koreancuisine:pepper_seeds
  
  2. 경작지(Farmland)에 씨앗 심기
  3. 8단계 성장 후 수확 (밀과 동일)
  
▣ 음식 제작
  - 배추 → 화덕 조리 → 김치
  - 무 → 화덕 조리 → 깍두기
  - 고추 → 화덕 조리 → 고추장

▣ 화덕 사용
  /give @p koreancuisine:korean_furnace
  - 일반 화로(Furnace)와 동일하게 사용
  - 연료 + 재료 넣고 조리

【문제 해결】

 Q: 모드가 목록에 안 보여요
 A: Forge 버전과 Minecraft 버전 확인 (둘 다 1.21.1)

 Q: 게임이 크래시돼요
 A: logs/latest.log 파일 확인 → 오류 메시지 검색

 Q: 텍스처가 보라색/검은색이에요
 A: 리소스 팩 충돌 확인 또는 모드 재설치

【개발 환경 세팅 (모더용)】

1. JDK 17 설치
2. 이 폴더에서 명령어 실행:
   
   Windows: gradlew.bat genIntellijRuns
   Mac/Linux: ./gradlew genIntellijRuns

3. IntelliJ IDEA에서 프로젝트 열기
4. Run Configuration "runClient" 선택 → 실행

=== 즐거운 한식 라이프 되세요! ===