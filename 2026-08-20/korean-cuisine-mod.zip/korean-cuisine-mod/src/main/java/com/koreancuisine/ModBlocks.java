package com.koreancuisine;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.koreancuisine.block.*;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, KoreanCuisineMod.MOD_ID);

    public static final RegistryObject<Block> CABBAGE_CROP = BLOCKS.register("cabbage_crop",
        () -> new CabbageCropBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.WHEAT)));
    
    public static final RegistryObject<Block> RADISH_CROP = BLOCKS.register("radish_crop",
        () -> new RadishCropBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.WHEAT)));
    
    public static final RegistryObject<Block> PEPPER_CROP = BLOCKS.register("pepper_crop",
        () -> new PepperCropBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.WHEAT)));
    
    public static final RegistryObject<Block> KOREAN_FURNACE = BLOCKS.register("korean_furnace",
        () -> new KoreanFurnaceBlock(BlockBehaviour.Properties.ofFullCopy(Blocks.FURNACE)));
}