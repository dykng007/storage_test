package com.koreancuisine;

import net.minecraft.world.item.*;
import net.minecraft.world.food.FoodProperties;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, KoreanCuisineMod.MOD_ID);

    public static final RegistryObject<Item> CABBAGE_SEEDS = ITEMS.register("cabbage_seeds",
        () -> new ItemNameBlockItem(ModBlocks.CABBAGE_CROP.get(), new Item.Properties()));
    
    public static final RegistryObject<Item> RADISH_SEEDS = ITEMS.register("radish_seeds",
        () -> new ItemNameBlockItem(ModBlocks.RADISH_CROP.get(), new Item.Properties()));
    
    public static final RegistryObject<Item> PEPPER_SEEDS = ITEMS.register("pepper_seeds",
        () -> new ItemNameBlockItem(ModBlocks.PEPPER_CROP.get(), new Item.Properties()));
    
    public static final RegistryObject<Item> CABBAGE = ITEMS.register("cabbage",
        () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3f).build())));
    
    public static final RegistryObject<Item> RADISH = ITEMS.register("radish",
        () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3f).build())));
    
    public static final RegistryObject<Item> PEPPER = ITEMS.register("pepper",
        () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.2f).build())));
    
    public static final RegistryObject<Item> KIMCHI = ITEMS.register("kimchi",
        () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.6f).build())));
    
    public static final RegistryObject<Item> KKAKDUGI = ITEMS.register("kkakdugi",
        () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.6f).build())));
    
    public static final RegistryObject<Item> GOCHUJANG = ITEMS.register("gochujang",
        () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.4f).build())));
    
    public static final RegistryObject<Item> KOREAN_FURNACE_ITEM = ITEMS.register("korean_furnace",
        () -> new BlockItem(ModBlocks.KOREAN_FURNACE.get(), new Item.Properties()));
}