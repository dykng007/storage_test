=== 농사 확장 데이터팩 설치 방법 ===

1. 이 zip 파일을 그대로 압축 해제하지 마세요
2. Minecraft를 실행하고 원하는 월드를 선택하세요
3. 월드 폴더로 이동:
   - Windows: %appdata%\.minecraft\saves\<월드이름>\datapacks\
   - Mac: ~/Library/Application Support/minecraft/saves/<월드이름>/datapacks/
   - Linux: ~/.minecraft/saves/<월드이름>/datapacks/
4. 이 zip 파일을 datapacks 폴더에 복사하세요
5. 게임에서 /reload 명령어를 실행하거나 월드를 재접속하세요

=== 추가된 작물 ===

* 토마토 (4단계 성장)
  - 씨앗: 잔디 파괴 시 드롭
  - 수확: 토마토 아이템
  
* 옥수수 (4단계 성장)
  - 씨앗: 잔디 파괴 시 드롭
  - 수확: 옥수수 아이템
  
* 벼 (4단계 성장)
  - 씨앗: 잔디 파괴 시 드롭
  - 수확: 쌀 아이템

=== 특수 아이템 ===

* 마법 괭이
  - 제작: 다이아몬드 괭이 + 네더의 별
  - 기능: 3x3 범위 경작

=== 명령어 ===

/function farming:give_seeds - 모든 씨앗 지급
/function farming:give_magic_hoe - 마법 괭이 지급

=== 문의 ===

버그 신고 및 건의사항은 개발팀으로 연락주세요.
