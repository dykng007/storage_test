tag @s remove tomato_stage1
tag @s add tomato_stage2
setblock ~ ~ ~ potatoes[age=2]
particle minecraft:composter ~ ~1 ~ 0.3 0.3 0.3 0 5
