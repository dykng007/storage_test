give @s minecraft:wheat_seeds{display:{Name:'{"text":"토마토 씨앗","color":"red"}',Lore:['{"text":"붉은 토마토로 자랍니다"}']},CustomModelData:1,farming_seed:"tomato"} 16
give @s minecraft:wheat_seeds{display:{Name:'{"text":"옥수수 씨앗","color":"yellow"}',Lore:['{"text":"노란 옥수수로 자랍니다"}']},CustomModelData:2,farming_seed:"corn"} 16
give @s minecraft:wheat_seeds{display:{Name:'{"text":"벼 씨앗","color":"green"}',Lore:['{"text":"쌀로 수확됩니다"}']},CustomModelData:3,farming_seed:"rice"} 16
tellraw @s {"text":"모든 씨앗을 받았습니다!","color":"green"}
