tag @s remove corn_stage3
tag @s add corn_stage4
setblock ~ ~ ~ carrots[age=7]
particle minecraft:happy_villager ~ ~1 ~ 0.3 0.3 0.3 0 10
