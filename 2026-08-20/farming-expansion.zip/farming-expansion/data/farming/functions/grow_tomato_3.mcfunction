tag @s remove tomato_stage2
tag @s add tomato_stage3
setblock ~ ~ ~ potatoes[age=5]
particle minecraft:composter ~ ~1 ~ 0.3 0.3 0.3 0 5
