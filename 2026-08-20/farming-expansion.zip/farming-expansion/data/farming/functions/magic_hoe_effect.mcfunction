# 3x3 경작 효과
execute if predicate farming:holding_magic_hoe if predicate farming:sneaking at @s positioned ~-1 ~ ~-1 run function farming:till_area
