# 3x3 영역 경작
fill ~0 ~ ~0 ~2 ~ ~2 farmland replace grass_block
fill ~0 ~ ~0 ~2 ~ ~2 farmland replace dirt
particle minecraft:happy_villager ~1 ~1 ~1 1 0.5 1 0 20
playsound minecraft:item.hoe.till player @a[distance=..10] ~ ~ ~ 1 1
