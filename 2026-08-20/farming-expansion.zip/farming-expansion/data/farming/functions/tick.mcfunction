# 마법 괭이 감지 및 효과
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_hoe",tag:{magic_hoe:1b}}}] at @s run function farming:magic_hoe_effect

# 작물 성장 체크 (랜덤 틱 보조)
execute as @e[type=marker,tag=farming_crop] at @s run function farming:crop_growth_check
