tag @s remove corn_stage1
tag @s add corn_stage2
setblock ~ ~ ~ carrots[age=2]
particle minecraft:composter ~ ~1 ~ 0.3 0.3 0.3 0 5
