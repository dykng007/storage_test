tellraw @a {"text":"[농사 확장] 데이터팩이 로드되었습니다!","color":"green"}
tellraw @a {"text":"명령어: /function farming:give_seeds (씨앗 지급)","color":"yellow"}
tellraw @a {"text":"명령어: /function farming:give_magic_hoe (마법 괭이 지급)","color":"yellow"}
