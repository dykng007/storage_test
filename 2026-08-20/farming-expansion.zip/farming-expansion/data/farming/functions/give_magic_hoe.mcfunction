give @s minecraft:diamond_hoe{display:{Name:'{"text":"마법 괭이","color":"light_purple","bold":true}',Lore:['{"text":"웅크리기 + 우클릭으로"}','{"text":"3x3 영역을 경작합니다"}']},Enchantments:[{id:"efficiency",lvl:5},{id:"unbreaking",lvl:3}],magic_hoe:1b} 1
tellraw @s {"text":"마법 괭이를 받았습니다!","color":"light_purple"}
