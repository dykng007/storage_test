tag @s remove tomato_stage3
tag @s add tomato_stage4
setblock ~ ~ ~ potatoes[age=7]
particle minecraft:happy_villager ~ ~1 ~ 0.3 0.3 0.3 0 10
