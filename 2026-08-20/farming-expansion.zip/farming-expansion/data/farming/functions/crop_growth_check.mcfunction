# 작물 성장 로직 (간소화)
execute if entity @s[tag=tomato_stage1] if predicate farming:random_grow run function farming:grow_tomato_2
execute if entity @s[tag=tomato_stage2] if predicate farming:random_grow run function farming:grow_tomato_3
execute if entity @s[tag=tomato_stage3] if predicate farming:random_grow run function farming:grow_tomato_4

execute if entity @s[tag=corn_stage1] if predicate farming:random_grow run function farming:grow_corn_2
execute if entity @s[tag=corn_stage2] if predicate farming:random_grow run function farming:grow_corn_3
execute if entity @s[tag=corn_stage3] if predicate farming:random_grow run function farming:grow_corn_4

execute if entity @s[tag=rice_stage1] if predicate farming:random_grow run function farming:grow_rice_2
execute if entity @s[tag=rice_stage2] if predicate farming:random_grow run function farming:grow_rice_3
execute if entity @s[tag=rice_stage3] if predicate farming:random_grow run function farming:grow_rice_4
