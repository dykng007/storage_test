tag @s remove rice_stage3
tag @s add rice_stage4
setblock ~ ~ ~ beetroots[age=3]
particle minecraft:happy_villager ~ ~1 ~ 0.3 0.3 0.3 0 10
