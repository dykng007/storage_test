tag @s remove rice_stage1
tag @s add rice_stage2
setblock ~ ~ ~ beetroots[age=1]
particle minecraft:composter ~ ~1 ~ 0.3 0.3 0.3 0 5
