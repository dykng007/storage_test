tag @s remove corn_stage2
tag @s add corn_stage3
setblock ~ ~ ~ carrots[age=5]
particle minecraft:composter ~ ~1 ~ 0.3 0.3 0.3 0 5
