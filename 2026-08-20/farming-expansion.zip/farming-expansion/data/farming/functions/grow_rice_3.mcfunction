tag @s remove rice_stage2
tag @s add rice_stage3
setblock ~ ~ ~ beetroots[age=2]
particle minecraft:composter ~ ~1 ~ 0.3 0.3 0.3 0 5
